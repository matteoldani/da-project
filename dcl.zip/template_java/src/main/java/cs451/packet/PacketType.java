package cs451.packet;

public enum PacketType {
    MSG,
    ACK
}
