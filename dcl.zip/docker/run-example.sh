#!/bin/bash

docker run  -it da_image /bin/bash 
